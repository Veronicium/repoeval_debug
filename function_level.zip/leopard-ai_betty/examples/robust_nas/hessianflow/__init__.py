"""
Hessian tool for neural networks based on pytorch 0.4.1
"""

name = "Hessian Flow"

from .eigen import *
