Architecture
============

.. figure:: ../_static/imgs/diagram.png
    :align: center

    Figure 2. Architecture diagram of Betty.

To be updated.